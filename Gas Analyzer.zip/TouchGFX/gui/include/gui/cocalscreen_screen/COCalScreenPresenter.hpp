#ifndef COCALSCREENPRESENTER_HPP
#define COCALSCREENPRESENTER_HPP

#include <gui/model/ModelListener.hpp>
#include <mvp/Presenter.hpp>

using namespace touchgfx;

class COCalScreenView;

class COCalScreenPresenter : public touchgfx::Presenter, public ModelListener
{
public:
    COCalScreenPresenter(COCalScreenView& v);

    /**
     * The activate function is called automatically when this screen is "switched in"
     * (ie. made active). Initialization logic can be placed here.
     */
    virtual void activate();

    /**
     * The deactivate function is called automatically when this screen is "switched out"
     * (ie. made inactive). Teardown functionality can be placed here.
     */
    virtual void deactivate();

    virtual ~COCalScreenPresenter() {}

    virtual void onCOCalDataUpdated(int16_t raw_co, float cal_co) override;

    void coZeroCalibrate();
    void coSpanCalibrate(float target_ppm);
    void coResetCalibrate();

private:
    COCalScreenPresenter();

    COCalScreenView& view;
};

#endif // COCALSCREENPRESENTER_HPP
