#ifndef MAINSCREENPRESENTER_HPP
#define MAINSCREENPRESENTER_HPP

#include <gui/model/ModelListener.hpp>
#include <mvp/Presenter.hpp>

using namespace touchgfx;

class mainScreenView;

class mainScreenPresenter : public touchgfx::Presenter, public ModelListener
{
public:
    mainScreenPresenter(mainScreenView& v);

    /**
     * The activate function is called automatically when this screen is "switched in"
     * (ie. made active). Initialization logic can be placed here.
     */
    virtual void activate();

    /**
     * The deactivate function is called automatically when this screen is "switched out"
     * (ie. made inactive). Teardown functionality can be placed here.
     */
    virtual void deactivate();

    virtual ~mainScreenPresenter() {}
     void tick();
     void onSht22Updated(float t, float h);
     void onGasUpdated(float co_ppm, float o2_percent);
     void onCO2Updated(float co2_ppm);
     void onProbeUpdated(float probe_temp);
     void updateTime(uint8_t hour,uint8_t minute,uint8_t second);

     void updateEEPROMStatus();
private:
    mainScreenPresenter();

    mainScreenView& view;
};

#endif // MAINSCREENPRESENTER_HPP
